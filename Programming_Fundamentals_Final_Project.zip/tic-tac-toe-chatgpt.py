from tkinter import *
import random

class TicTacToe:
    def __init__(self, window):
        self.window = window
        self.window.title("Tic-Tac-Toe")
        self.font_size_small = 14
        self.font_size_big = 20
        self.EMPTY = ""
        self.PLAYER_X = "X"
        self.PLAYER_O = "O"
        self.player_score = 0
        self.pc_score = 0
        self.board = [[self.EMPTY] * 3 for _ in range(3)]
        self.game_over = False

        self.create_widgets()
        self.restart()

    def create_widgets(self):
        self.label_score = Label(self.window, text=f"You: {self.player_score}   Computer: {self.pc_score}", font=("Arial", self.font_size_small))
        self.label_result = Label(self.window, text="", font=("Arial", self.font_size_big))
        self.restart_button = Button(self.window, text="Restart", command=self.restart, font=("Arial", self.font_size_small))

        self.label_score.grid(row=0, columnspan=3)
        self.label_result.grid(row=1, columnspan=3)
        self.restart_button.grid(row=2, columnspan=3)

        self.cells_buttons = [[None]*3 for _ in range(3)]
        for i in range(3):
            for j in range(3):
                self.cells_buttons[i][j] = Button(self.window, text="", width=10, height=3, command=lambda row=i, col=j: self.player_move(row, col), font=("Arial", self.font_size_big))
                self.cells_buttons[i][j].grid(row=i + 3, column=j)

    def restart(self):
        self.board = [[self.EMPTY] * 3 for _ in range(3)]
        self.game_over = False
        for button_row in self.cells_buttons:
            for button in button_row:
                button.config(text=self.EMPTY, state=NORMAL, bg='SystemButtonFace')
        self.label_result.config(text="")
    
    def check_winner(self):
        for i in range(3):
            if self.board[i][0] == self.board[i][1] == self.board[i][2] != self.EMPTY:
                self.highlight_winner([(i, 0), (i, 1), (i, 2)])
                return self.board[i][0]
            if self.board[0][i] == self.board[1][i] == self.board[2][i] != self.EMPTY:
                self.highlight_winner([(0, i), (1, i), (2, i)])
                return self.board[0][i]
        if self.board[0][0] == self.board[1][1] == self.board[2][2] != self.EMPTY:
            self.highlight_winner([(0, 0), (1, 1), (2, 2)])
            return self.board[0][0]
        if self.board[0][2] == self.board[1][1] == self.board[2][0] != self.EMPTY:
            self.highlight_winner([(0, 2), (1, 1), (2, 0)])
            return self.board[0][2]
        return None

    def is_draw(self):
        return all(self.board[i][j] != self.EMPTY for i in range(3) for j in range(3))

    def update_board(self, row, col, mark):
        self.cells_buttons[row][col].config(text=mark, state=DISABLED)
        self.board[row][col] = mark

    def player_move(self, row, col):
        if not self.game_over and self.board[row][col] == self.EMPTY:
            self.update_board(row, col, self.PLAYER_X)
            winner = self.check_winner()
            if winner:
                self.game_over = True
                self.label_result.config(text=f"{winner} wins!")
                if winner == self.PLAYER_X:
                    self.player_score += 1
                else:
                    self.pc_score += 1
                self.update_score()
            elif self.is_draw():
                self.game_over = True
                self.label_result.config(text="It's a tie!", font=("Arial", self.font_size_big))
                self.highlight_all_cells()
            else:
                self.computer_move()

    def computer_move(self):
        if not self.game_over:
            empty_cells = [(i, j) for i in range(3) for j in range(3) if self.board[i][j] == self.EMPTY]
            if empty_cells:
                row, col = random.choice(empty_cells)
                self.update_board(row, col, self.PLAYER_O)
                winner = self.check_winner()
                if winner:
                    self.game_over = True
                    self.label_result.config(text=f"{winner} wins!")
                    if winner == self.PLAYER_X:
                        self.player_score += 1
                    else:
                        self.pc_score += 1
                    self.update_score()
                elif self.is_draw():
                    self.game_over = True
                    self.label_result.config(text="It's a tie!", font=("Arial", self.font_size_big))
                    self.highlight_all_cells()

    def highlight_winner(self, cells):
        for row, col in cells:
            self.cells_buttons[row][col].config(bg="cyan")

    def highlight_all_cells(self):
        for i in range(3):
            for j in range(3):
                self.cells_buttons[i][j].config(bg="red")

    def update_score(self):
        self.label_score.config(text=f"You: {self.player_score}   Computer: {self.pc_score}")

if __name__ == "__main__":
    window = Tk()
    game = TicTacToe(window)
    window.mainloop()
